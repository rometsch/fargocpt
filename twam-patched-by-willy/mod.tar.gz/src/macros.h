#ifndef _MACROS_H_
#define _MACROS_H_

#define CELL(nRadial, nAzimuthal, NAzimuthal) (((nRadial)*(NAzimuthal))+(nAzimuthal))

#endif
