#ifndef _SPLIT_H_
#define _SPLIT_H_

void SplitDomain();

#endif
