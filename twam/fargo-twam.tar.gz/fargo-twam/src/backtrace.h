#ifndef _BACKTRACE_H_
#define _BACKTRACE_H_

#define BACKTRACE_MAXDEPTH 10

void PrintTrace(void);

#endif
