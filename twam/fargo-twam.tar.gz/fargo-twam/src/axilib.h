#ifndef _AXILIB_H_
#define _AXILIB_H_

void mpi_make1Dprofile(double* grid, double* array);

#endif
